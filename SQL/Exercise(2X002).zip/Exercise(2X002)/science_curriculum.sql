select*from Science_curriculum;
DROP table Science_curriculum;
CREATE TABLE SCIENCE_CURRICULUM(ENROLLMENT_ID INT,NAME VARCHAR,MARKS INT);
INSERT INTO SCIENCE_CURRICULUM (ENROLLMENT_ID, NAME, MARKS)
VALUES
(1, 'Alice Johnson', 85),
(2, 'Bob Smith', 90),
(3, 'Charlie Brown', 78),
(4, 'Diana Prince', 88),
(5, 'Ethan Hunt', 92),
(6, 'Fiona Shaw', 79),
(7, 'George Miller', 84),
(8, 'Hannah White', 91);

SELECT * FROM SCIENCE_CURRICULUM;

