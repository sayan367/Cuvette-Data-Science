SELECT 
    customer.customer_id AS Customer_Table_ID,
    sales.customer_id AS Sales_Table_ID,
    sales.*
FROM 
    customer
LEFT JOIN 
    sales
ON 
    customer.customer_id = sales.customer_id;SELECT 
    customer.customer_id AS Customer_Table_ID,
    sales.customer_id AS Sales_Table_ID,
    sales.*
FROM 
    customer
LEFT JOIN 
    sales
ON 
    customer.customer_id = sales.customer_id;SELECT 
    customer.customer_id AS Customer_Table_ID,
    sales.customer_id AS Sales_Table_ID,
    sales.*
FROM 
    customer
LEFT JOIN 
    sales
ON 
    customer.customer_id = sales.customer_id;