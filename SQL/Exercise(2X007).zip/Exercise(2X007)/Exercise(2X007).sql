SELECT*FROM sales;
SELECT COUNT(*) FROM CUSTOMER WHERE REGION='SOUTH'OR REGION='EAST';
SELECT COUNT(DISTINCT CITY) AS UniqueCities
FROM CUSTOMER
WHERE Region = 'South' OR Region = 'East';
SELECT COUNT(DISTINCT order_id)FROM SALES WHERE SALES BETWEEN 100 AND 500;
SELECT COUNT(*)
FROM customer
WHERE customer_name LIKE '% ____'
---1.	Fetch all orders where the discount value is greater than zero, and sort the results in descending order based on the discount value.--

SELECT *
FROM SALES
WHERE Discount > 0
ORDER BY Discount DESC;

SELECT * 
FROM SALES
WHERE DISCOUNT > 0
ORDER BY DISCOUNT DESC
LIMIT 10;

